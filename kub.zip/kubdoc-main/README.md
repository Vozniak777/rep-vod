# RUET-ChatBot
It's a PHP, MySQL, Jquery ChatBot For My University RUET

# Demo

<a href="http://ruetchatbot.epizy.com">RUET ChatBot</a>


# Install
```
From Database Folder Import chat.sql into your database
Run Your Server
Type localhost/chatbot/chatbot.php on your Browser
```

# DevOps
## Deploy in Kubernetes
Watch this Video: https://www.youtube.com/watch?v=aG3Hq4KrvUI





